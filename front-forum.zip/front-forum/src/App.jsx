import AllRoutes from "./shared/routes/AllRoutes";

const App = () => {
  return <AllRoutes />;
};

export default App;
