import { request, response } from "express";
 
export const errorHandler = (err, request, response,next)=>{
    if(err){
        response.status(500).json({
            message:err.message,
            stack:err.stack
        })
    }
    else{
        next();
    }
}