export const messages={
    'login-failed':'Login-failed',
    'login-success':'user-registered',
    'Welcome':'Welcome user' 
}