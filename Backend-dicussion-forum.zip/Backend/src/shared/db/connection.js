import mongoose from 'mongoose';
export const createConnection=()=>{
const URL = "mongodb+srv://radhika:radhs123@discussion-forum-app.txam8uq.mongodb.net/forumdb?retryWrites=true&w=majority";
//console.log('jdbj',URL);
return mongoose.connect(URL);
}
