//format- it has label, timestamp, custom format-function defined,
//windton docs for getting info

import winston from 'winston';
export const mtLogger=(moduleName)=>{
    return winston.createLogger({
        level: process.env.NODE_ENV==='DEV'?'debug':'error',
        format:combine(
            label
        )

    }),
    new winston.transports.File({
        filename: 'logs/error.logs'
    }),
    new winston.transports.File({
        filename: 'logs'
    })
}