import {userService} from '../service/user-service.js'
export const login=async(request,response)=>{
    try{
    const user=request.body;
    const doc=await userService.login(user);
    response.status(200).json(doc);
    }catch(err){
        response.status(500).json({message:'Application Crash'});
        console.log(err);
    }
}
export const register=async(request,response,next)=>{
    try{
    const user=request.body;
    const doc=await userService.register(user);
    response.status(200).json({message:'Register User',user:doc});

    }
    catch(err){
        response.status(500).json({message:'Application Crash'});
        console.log(err);
    }
    //response.send('Register');

}